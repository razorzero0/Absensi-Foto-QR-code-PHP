@extends('admin/layout/main')
@section('container')
<div class="container ">
    
    <br>
    <br>
    <br>
    <br>
    <div class="mt-100">
<h3 class="text-center">Berhasil Absen, <a href="/dashboard">kembali dashboard</a></h3>
    </div>
</div>
@endsection